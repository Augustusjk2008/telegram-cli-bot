"""Main/header floating pictures from PlcSpa and OfficeArt."""

from __future__ import annotations

from collections.abc import Callable, Mapping, Set
from dataclasses import dataclass, replace

from ..diagnostics import ConversionReport, SourceLocation
from ..errors import InvalidWordDocument
from ..model import CharacterProperties, FloatingPicture
from .header_textboxes import ShapeAnchor
from .officeart import OfficeArtShapeCollection

# OfficeArt / VML geometry space. Used when tight/through wrap is requested but
# pWrapPolygonVertices is absent — the picture frame itself is the only safe
# contour evidence.
_BOUNDING_RECT_WRAP_POLYGON: tuple[tuple[int, int], ...] = (
    (0, 0),
    (21600, 0),
    (21600, 21600),
    (0, 21600),
    (0, 0),
)
# Word's UI default left/right wrap distance when OfficeArt omits dxWrapDist*.
_DEFAULT_WRAP_DIST_LR_EMU = 9 * 12700


@dataclass(slots=True, frozen=True)
class FloatingPictureCollection:
    pictures: tuple[FloatingPicture, ...] = ()
    by_anchor_cp: Mapping[int, FloatingPicture] | None = None
    deferred_count: int = 0
    non_picture_shape_count: int = 0

    def picture_at(self, cp: int) -> FloatingPicture | None:
        return (self.by_anchor_cp or {}).get(cp)


def _read_floating_pictures(
    anchors_by_shape_id: Mapping[int, ShapeAnchor],
    officeart: OfficeArtShapeCollection,
    *,
    anchor_story_cp_start: int,
    anchor_story_name: str,
    spa_structure: str,
    excluded_shape_ids: Set[int] | frozenset[int] = frozenset(),
    first_picture_id: int = 1,
    report: ConversionReport,
    character_properties_at: Callable[[int], CharacterProperties],
) -> FloatingPictureCollection:
    """Associate one story's shape anchors with supported OfficeArt BLIPs."""

    if first_picture_id <= 0:
        raise ValueError("first_picture_id must be positive")
    pictures: list[FloatingPicture] = []
    by_anchor_cp: dict[int, FloatingPicture] = {}
    deferred_count = 0
    non_picture_shape_count = 0
    approximated_wrap_count = 0
    for anchor in sorted(
        anchors_by_shape_id.values(),
        key=lambda value: value.anchor_cp,
    ):
        absolute_anchor_cp = anchor_story_cp_start + anchor.anchor_cp
        if anchor.shape_id in excluded_shape_ids:
            continue
        image = officeart.image_at(anchor.shape_id)
        if image is None:
            unsupported_type = officeart.unsupported_image_type_at(anchor.shape_id)
            if unsupported_type is not None:
                deferred_count += 1
                report.warning(
                    "FLOATING_PICTURE_FORMAT_DEFERRED",
                    "a floating picture uses an unsupported OfficeArt BLIP format",
                    location=SourceLocation(
                        story=anchor_story_name,
                        cp_start=absolute_anchor_cp,
                        cp_end=absolute_anchor_cp + 1,
                    ),
                    shape_id=anchor.shape_id,
                    record_type=f"0x{unsupported_type:04X}",
                )
            else:
                non_picture_shape_count += 1
            continue
        properties = character_properties_at(absolute_anchor_cp)
        if properties.special is not True:
            raise InvalidWordDocument(
                f"{spa_structure} picture anchor at CP {anchor.anchor_cp} "
                "has no sprmCFSpec"
            )
        if absolute_anchor_cp in by_anchor_cp:
            raise InvalidWordDocument(
                f"multiple floating pictures use {anchor_story_name} CP "
                f"{anchor.anchor_cp}"
            )
        wrap_polygon = officeart.wrap_polygon_at(anchor.shape_id)
        if anchor.wrap_type in ("tight", "through") and not wrap_polygon:
            # Keep the native wrap kind with a rectangular contour instead of
            # silently demoting to wrapSquare, which changes Word's wrap engine.
            wrap_polygon = _BOUNDING_RECT_WRAP_POLYGON
            approximated_wrap_count += 1
        wrap_distances = officeart.wrap_distances_at(anchor.shape_id)
        if wrap_distances is None:
            if anchor.wrap_type in ("square", "tight", "through"):
                wrap_dist_left = wrap_dist_right = _DEFAULT_WRAP_DIST_LR_EMU
            else:
                wrap_dist_left = wrap_dist_right = 0
            wrap_dist_top = wrap_dist_bottom = 0
        else:
            (
                wrap_dist_left,
                wrap_dist_top,
                wrap_dist_right,
                wrap_dist_bottom,
            ) = wrap_distances
        picture = FloatingPicture(
            picture_id=first_picture_id + len(pictures),
            shape_id=anchor.shape_id,
            anchor_cp=absolute_anchor_cp,
            data=image.data,
            extension=image.extension,
            content_type=image.content_type,
            left_twips=anchor.left,
            top_twips=anchor.top,
            width_twips=max(anchor.right - anchor.left, 1),
            height_twips=max(anchor.bottom - anchor.top, 1),
            horizontal_relative=anchor.horizontal_relative,
            vertical_relative=(
                officeart.vertical_relative_at(anchor.shape_id)
                or anchor.vertical_relative
            ),
            wrap_type=anchor.wrap_type,
            wrap_side=anchor.wrap_side,
            behind_text=anchor.behind_text,
            anchor_locked=anchor.anchor_locked,
            wrap_polygon=wrap_polygon,
            wrap_dist_top_emu=wrap_dist_top,
            wrap_dist_bottom_emu=wrap_dist_bottom,
            wrap_dist_left_emu=wrap_dist_left,
            wrap_dist_right_emu=wrap_dist_right,
            flip_horizontal=officeart.is_horizontally_flipped(anchor.shape_id),
            flip_vertical=officeart.is_vertically_flipped(anchor.shape_id),
            rotation_degrees=officeart.rotation_at(anchor.shape_id),
            properties=replace(
                properties,
                special=None,
                picture_location=None,
                picture_is_binary=None,
            ),
        )
        pictures.append(picture)
        by_anchor_cp[absolute_anchor_cp] = picture

    if approximated_wrap_count:
        report.warning(
            "FLOATING_PICTURE_WRAP_APPROXIMATED",
            "tight/through picture wrap without OfficeArt contour vertices used "
            "the picture bounding rectangle as the wrap polygon",
            location=SourceLocation(story=anchor_story_name),
            picture_count=approximated_wrap_count,
        )
    return FloatingPictureCollection(
        pictures=tuple(pictures),
        by_anchor_cp=by_anchor_cp,
        deferred_count=deferred_count,
        non_picture_shape_count=non_picture_shape_count,
    )


def read_main_floating_pictures(
    anchors_by_shape_id: Mapping[int, ShapeAnchor],
    officeart: OfficeArtShapeCollection,
    *,
    excluded_shape_ids: Set[int] | frozenset[int] = frozenset(),
    first_picture_id: int = 1,
    report: ConversionReport,
    character_properties_at: Callable[[int], CharacterProperties],
) -> FloatingPictureCollection:
    """Associate main-story shape anchors with supported OfficeArt BLIPs."""

    return _read_floating_pictures(
        anchors_by_shape_id,
        officeart,
        anchor_story_cp_start=0,
        anchor_story_name="main",
        spa_structure="PlcSpaMom",
        excluded_shape_ids=excluded_shape_ids,
        first_picture_id=first_picture_id,
        report=report,
        character_properties_at=character_properties_at,
    )


def read_header_floating_pictures(
    anchors_by_shape_id: Mapping[int, ShapeAnchor],
    officeart: OfficeArtShapeCollection,
    *,
    header_story_cp_start: int,
    excluded_shape_ids: Set[int] | frozenset[int] = frozenset(),
    first_picture_id: int = 1,
    report: ConversionReport,
    character_properties_at: Callable[[int], CharacterProperties],
) -> FloatingPictureCollection:
    """Associate header/footer shape anchors with supported OfficeArt BLIPs."""

    return _read_floating_pictures(
        anchors_by_shape_id,
        officeart,
        anchor_story_cp_start=header_story_cp_start,
        anchor_story_name="headers",
        spa_structure="PlcSpaHdr",
        excluded_shape_ids=excluded_shape_ids,
        first_picture_id=first_picture_id,
        report=report,
        character_properties_at=character_properties_at,
    )
